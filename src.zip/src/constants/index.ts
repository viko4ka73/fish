import { sale } from "../assets/images";
export const navLinks = [
    { href: "#home", label: "Продукция" },
    { href: "#about-us", label: "О нас" },
    { href: "#products", label: "Доставка и оплата" },
    { href: "#contact-us", label: "Контакты" },
];
export const productions = [
    {
        id:1,
        name: "Акции",
        img: sale,
    },
    {
        id:2,
        name: "Продукция",
        img: sale,
    },
    {
        id:3,
        name: "Продукция",
        img: sale,
    },
    {
        id:4,
        name: "Продукция",
        img: sale,
    },
    {
        id:5,
        name: "Продукция",
        img: sale,
    },
    {
        id:6,
        name: "Продукция",
        img: sale,
    },
];